import 'package:flutter/material.dart';
import 'package:water_reminder/ui/hydration_pool/person_view.dart';
import 'package:water_reminder/ui/login_screen/select_time_schuled.dart';
import 'package:water_reminder/ui/login_screen/weight_height.dart';

class LoginPageViewBuilder extends StatefulWidget {
  const LoginPageViewBuilder({super.key});

  static _LoginPageViewBuilderState? of(BuildContext context) =>
      context.findRootAncestorStateOfType<_LoginPageViewBuilderState>();
  @override
  State<LoginPageViewBuilder> createState() => _LoginPageViewBuilderState();
}

class _LoginPageViewBuilderState extends State<LoginPageViewBuilder>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final PageController _pageController = PageController();
  @override
  void initState() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _controller.repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  nextPage() {
    _pageController.nextPage(
        duration: const Duration(milliseconds: 600), curve: Curves.bounceIn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Align(
            alignment: const Alignment(0.0, -0.1),
            child: PersonView(animation: _controller),
          ),
          PageView.builder(
            itemCount: 2,
            physics: const NeverScrollableScrollPhysics(),
            controller: _pageController,
            itemBuilder: (context, index) => [
              const WeightAndHeightScreen(),
              const SelectTimeSchema()
            ].elementAt(index),
          ),
        ],
      ),
    );
  }
}
