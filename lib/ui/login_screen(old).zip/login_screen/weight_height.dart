import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:water_reminder/constant/loader.dart';
import 'package:water_reminder/domain/model/user_model.dart';
import 'package:water_reminder/domain/repository/person_repository.dart';
import 'package:water_reminder/ui/login_screen/login_page_view.dart';
import 'package:water_reminder/ui/widgets/custom_textformfiled.dart';
import 'package:water_reminder/ui/widgets/item_padding.dart';
import 'package:water_reminder/ui/widgets/primary_button.dart';
import 'package:water_reminder/ui/widgets/vertical_space.dart';

class WeightAndHeightScreen extends StatefulWidget {
  const WeightAndHeightScreen({Key? key}) : super(key: key);

  @override
  State<WeightAndHeightScreen> createState() => _WeightAndHeightScreenState();
}

class _WeightAndHeightScreenState extends State<WeightAndHeightScreen> {
  late final TextEditingController weightController;
  late final TextEditingController heightController;
  late final TextEditingController nameController;
  late final TextEditingController consumptionTargetController;
  final PersonRepository personRepository = PersonRepository();
  final _formKey = GlobalKey<FormState>();
  RepeatInterval repeatInterval = RepeatInterval.hourly;

  @override
  void initState() {
    super.initState();
    weightController = TextEditingController();
    heightController = TextEditingController();
    nameController = TextEditingController();
    consumptionTargetController = TextEditingController();
  }

  @override
  void dispose() {
    weightController.dispose();
    heightController.dispose();
    nameController.dispose();
    consumptionTargetController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.transparent,
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).size.height * 0.3,
            ),
            physics: const BouncingScrollPhysics(),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ItemHorizontalPadding(
                  child: CustomTextFormField(
                    textController: nameController,
                    labelText: 'Name',
                    hintText: 'Enter your name',
                  ),
                ),
                const VerticalSpace(height: 16),
                ItemHorizontalPadding(
                  child: CustomTextFormField(
                    textController: weightController,
                    labelText: 'Weight',
                    hintText: 'Enter your weight',
                    inputType: TextInputType.number,
                    textValidator: (p0) {
                      if (p0!.isEmpty) {
                        return 'Please enter your weight';
                      } else if (double.tryParse(p0) != null &&
                          double.parse(p0) < 0.0) {
                        return 'Please enter your weight';
                      }
                      return null;
                    },
                  ),
                ),
                const VerticalSpace(height: 16),
                ItemHorizontalPadding(
                  child: CustomTextFormField(
                    textController: heightController,
                    inputType: TextInputType.number,
                    labelText: 'Height',
                    hintText: 'Enter your height',
                    textValidator: (p0) {
                      if (p0!.isEmpty) {
                        return 'Please enter your height';
                      } else if (double.tryParse(p0) != null &&
                          double.parse(p0) < 0.0) {
                        return 'Please enter your height';
                      }
                      return null;
                    },
                  ),
                ),
                const VerticalSpace(height: 16),
                ItemHorizontalPadding(
                  child: CustomTextFormField(
                    textController: consumptionTargetController,
                    inputType: TextInputType.number,
                    labelText: 'Target',
                    hintText: 'your target water(milliliter)',
                    textValidator: (p0) {
                      if (p0!.isEmpty) {
                        return 'Please enter your target water consumption';
                      } else if (double.tryParse(p0) != null &&
                          double.parse(p0) < 0.0) {
                        return 'Please enter your target water consumption';
                      }
                      return null;
                    },
                  ),
                ),
                const VerticalSpace(height: 16),
                PrimaryButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      UserModel.defaultConsumptionTarget =
                          int.parse(consumptionTargetController.text);
                      createUsers(UserModel(
                          weight: double.parse(weightController.text),
                          height: double.parse(heightController.text),
                          name: nameController.text,
                          consumptionTarget:
                              int.parse(consumptionTargetController.text)));
                    }
                    //Navigator.pushNamed(context, '/home');
                  },
                  title: "Save and continue",
                  color: Colors.black54,
                ),
              ],
            ),
          ),
        ));
  }

  createUsers(UserModel user) async {
    CustomLoader.of(context)?.showLoader();

    await personRepository.createUsers(user).then((val) {
      CustomLoader.of(context)?.hideLoader();
      if (val) {
        LoginPageViewBuilder.of(context)?.nextPage();
      }
    });
  }
}
