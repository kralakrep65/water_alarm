import 'package:flutter/material.dart';
import 'package:water_reminder/constant/notification_helper.dart';
import 'package:water_reminder/constant/shared_preferences_helper.dart';
import 'package:water_reminder/constant/size_config.dart';
import 'package:water_reminder/ui/home/home_page.dart';
import 'package:water_reminder/ui/login_screen/widgets/picker_button.dart';
import 'package:water_reminder/ui/widgets/item_padding.dart';
import 'package:water_reminder/ui/widgets/primary_button.dart';
import 'package:water_reminder/ui/widgets/vertical_space.dart';
import 'package:water_reminder/util/dialog.dart';

class SelectTimeSchema extends StatefulWidget {
  const SelectTimeSchema({super.key, this.isFromSetting});
  final bool? isFromSetting;
  @override
  State<SelectTimeSchema> createState() => _SelectTimeSchemaState();
}

class _SelectTimeSchemaState extends State<SelectTimeSchema> {
  String? selectedIntervalValue;
  String? selectedStartOfDay;
  String? selectedEndOfDay;
  TextEditingController controller = TextEditingController();
  List<String> stringList = [
    "every half hour",
    "every 1 hours",
    "every one and a half hours"
        "every 2 hours",
    "every two and a half hours"
        "every 3 hours",
  ];
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: (widget.isFromSetting ?? false)
          ? const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/water_bg.jpg"), fit: BoxFit.cover),
            )
          : const BoxDecoration(),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: ListView(
          children: [
            const VerticalSpace(height: 52),
            const ItemHorizontalPadding(
                child: Text("Choose your time schema",
                    style: TextStyle(fontSize: 36))),
            const VerticalSpace(height: 16),
            Padding(
                padding: EdgeInsets.only(
                    bottom: sizeConfig.heightSize(context, 64))),
            const ItemHorizontalPadding(
              child: Text(
                "Notification period:",
                style: TextStyle(fontSize: 12),
              ),
            ),
            const VerticalSpace(height: 4),
            ItemHorizontalPadding(
              child: Row(
                children: [
                  Expanded(
                    child: CustomPickerButton(
                      onPressed: () {
                        showPickerDialog(
                          context,
                          stringList: stringList,
                          onSelectedItemChanged: (value) {
                            setState(() {
                              selectedIntervalValue = stringList[value];
                            });
                          },
                          textEditingController: controller,
                          onConfirm: () {
                            if (controller.text.isNotEmpty) {
                              selectedIntervalValue = controller.text;
                            }
                            Navigator.pop(context);
                          },
                        );
                      },
                      title: createAPeriodTitle(selectedIntervalValue) ?? "",
                    ),
                  ),
                ],
              ),
            ),
            const VerticalSpace(height: 16),
            const ItemHorizontalPadding(
              child: Text(
                "Start of day:",
                style: TextStyle(fontSize: 12),
              ),
            ),
            const VerticalSpace(height: 4),
            ItemHorizontalPadding(
              child: Row(
                children: [
                  Expanded(
                    child: CustomPickerButton(
                      onPressed: () {
                        selectTime(context, (value) {
                          setState(() {
                            selectedStartOfDay =
                                "${value.hour.toString().length == 1 ? ('0${value.hour}') : value.hour}:${value.minute.toString().length == 1 ? ('0${value.minute}') : value.minute}";
                          });
                        });
                      },
                      title: selectedStartOfDay ?? "Select start of day",
                    ),
                  ),
                ],
              ),
            ),
            const VerticalSpace(height: 16),
            const ItemHorizontalPadding(
              child: Text(
                "End of day:",
                style: TextStyle(fontSize: 12),
              ),
            ),
            const VerticalSpace(height: 4),
            ItemHorizontalPadding(
              child: Row(
                children: [
                  Expanded(
                    child: CustomPickerButton(
                      onPressed: () {
                        selectTime(context, (value) {
                          setState(() {
                            selectedEndOfDay =
                                "${value.hour.toString().length == 1 ? ('0${value.hour}') : value.hour}:${value.minute.toString().length == 1 ? ('0${value.minute}') : value.minute}";
                          });
                        });
                      },
                      title: selectedEndOfDay ?? "Select end of day",
                    ),
                  ),
                ],
              ),
            ),
            const VerticalSpace(height: 16),
            ItemHorizontalPadding(
              child: PrimaryButton(
                onPressed: () {
                  if (selectedIntervalValue == null ||
                      selectedStartOfDay == null ||
                      selectedEndOfDay == null) {
                    showAnimatedPopup(
                      context,
                      "Please select all fields",
                    );
                  } else {
                    saveAndComplete().whenComplete(() {
                      Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePage(),
                          ),
                          (route) => false);
                    });
                  }
                },
                title: "Save and complete",
                color: Colors.black54,
              ),
            ),
          ],
        ),
      ),
    );
  }

  createAPeriodTitle(String? selectedIntervalValue) {
    if (controller.text.isNotEmpty) {
      return "every ${controller.text} minutes";
    } else {
      return selectedIntervalValue ?? "Chose Notification Sending Interval";
    }
  }

  Future saveAndComplete() async {
    if (widget.isFromSetting ?? false) {
      stopNotification();
    }
    await SharedPreferencesHelper().setDataToSharedPref("selectedIntervalValue",
        getIntervalPeriodTime(selectedIntervalValue ?? "").toString());
    await SharedPreferencesHelper()
        .setDataToSharedPref("selectedStartOfDay", selectedStartOfDay ?? "");
    await SharedPreferencesHelper()
        .setDataToSharedPref("selectedEndOfDay", selectedEndOfDay ?? "");
    await initializeNotificationService();
  }

  calculateIntervalDate(String intervalName) {
    switch (intervalName) {
      case "every half hour":
        return 30;
      case "every 1 hours":
        return 60;
      case "every one and a half hours":
        return 90;
      case "every 2 hours":
        return 120;
      case "every two and a half hours":
        return 150;
      case "every 3 hours":
        return 180;
    }
  }

  int getIntervalPeriodTime(String intervalName) {
    if (controller.text.isNotEmpty) {
      return int.parse(controller.text);
    } else {
      return calculateIntervalDate(intervalName);
    }
  }
}
